prompt --application/shared_components/user_interface/lovs/empleados_codigo_usuario
begin
--   Manifest
--     EMPLEADOS.CODIGO_USUARIO
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.15'
,p_default_workspace_id=>7697821598969118
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'WKSP_WORKPLACE'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(20621974182530291)
,p_lov_name=>'EMPLEADOS.CODIGO_USUARIO'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'EMPLEADOS'
,p_return_column_name=>'ID_EMPLEADO'
,p_display_column_name=>'CODIGO_USUARIO'
,p_default_sort_column_name=>'CODIGO_USUARIO'
,p_default_sort_direction=>'ASC'
,p_version_scn=>39028489273075
,p_created_on=>wwv_flow_imp.dz('20260513195956Z')
,p_updated_on=>wwv_flow_imp.dz('20260513195956Z')
,p_created_by=>'SIS_APEX'
,p_updated_by=>'SIS_APEX'
);
wwv_flow_imp.component_end;
end;
/
